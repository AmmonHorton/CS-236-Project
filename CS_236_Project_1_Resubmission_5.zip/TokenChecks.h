//
//  Tokenizer.h
//  CS_236_Project_1
//
//  Created by AMMON HORTON on 1/26/21.
//

#ifndef TokenChecks_h
#define TokenChecks_h


#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <sstream>
using namespace std;

class TokenCheck {
private:
    string selfType;
    string currentInput;
    size_t characterRead;
    size_t linePos;
    bool endOfFile;
public:
    TokenCheck(string st = "tokenCheck", string defaultInput = "", size_t defaultCharacterPos = 0, size_t defaultLine = 0) : selfType(st), currentInput(defaultInput), characterRead(defaultCharacterPos), linePos(defaultLine), endOfFile(false) {}
    virtual ~TokenCheck(void) {}
    
    TokenCheck(const TokenCheck &tc) {
        selfType = tc.selfType;
        currentInput = tc.currentInput;
        characterRead = tc.characterRead;
        linePos = tc.linePos;
        endOfFile = tc.endOfFile;
    }
    size_t GetRead(string input, bool eof = false){
        endOfFile = eof;
        if(input == currentInput) return characterRead;
        else{
            currentInput = input;
            DeclineState();
            S0();
            return characterRead;
        }
    }
    bool getFileStatus() {return endOfFile;}
    size_t GetRead(){return characterRead;}
    size_t InputSize(void) {return currentInput.size();}
    char CheckChar(void) {
        if(GetRead() == InputSize()) {
            DeclineState();
            return '\n';
        }
        return currentInput.at(characterRead);
        
    }
    string GetInput() {return currentInput;}
    void IncCharacter(void) {characterRead++;}
    void DeclineState(void) {characterRead = 0;}
    virtual void S0() = 0;
    string str(){
        ostringstream os;
        os << "(" << selfType << ",\"" << currentInput.substr(0, characterRead) << "\"," << linePos << ")";
        return os.str();
    }
    bool operator==(const TokenCheck& tc) {return this->selfType == tc.selfType;}
    void SetVar(string input, size_t characterPos, size_t line) {
        characterRead = characterPos;
        currentInput = input;
        linePos = line;
        return;
    }
    void SetVar(size_t line) {linePos = line; return;}
    bool accepting;
};



class UndefinedCheck : public TokenCheck {
public:
    UndefinedCheck(string st = "UNDEFINED", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st, defaultInput, defaultCharacterPos) {}
    UndefinedCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        DeclineState();
        return;
    }
};

class EOFCheck : public TokenCheck {
public:
    EOFCheck(string st = "EOF", size_t line = 0, string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st, defaultInput, defaultCharacterPos, line) {}
    void S0() {
        DeclineState();
        return;
    }
    string str(){
        return ("");
    }
};


class StringCheck : public TokenCheck {
public:
    StringCheck(string st = "STRING", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st, defaultInput, defaultCharacterPos) {}
    StringCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        accepting = false;
        if(CheckChar()== '\'') {
            IncCharacter();
            S1();
        }
        else DeclineState();
        return;
    }
    void S1() {
        if(GetRead() == InputSize() && !getFileStatus()) {accepting = true; return;}
        else if (GetRead() == InputSize() && getFileStatus()) {
            DeclineState();
            return;
        }
        if(CheckChar() != '\'') {
            IncCharacter();
            S1();
        }
        else{
            IncCharacter();
            S2();
        }
        return;
    }
    void S2() {
        if(GetRead() == InputSize()) return;
        if(CheckChar() == '\'') {
            IncCharacter();
            S1();
        }
        else {
            accepting = true;
            return;
        }
    }
};

class CommentCheck : public TokenCheck {
public:
    CommentCheck(string st = "COMMENT", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    CommentCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        accepting = false;
        if(CheckChar()== '#') {
            IncCharacter();
            S1();
        }
        else DeclineState();
        return;
    }
    void S1() {
        if(CheckChar() == '|') {
            IncCharacter();
            S2Block();
        }
        else{
            IncCharacter();
            S2Line();
        }
        return;
    }
    void S2Block() {
        if(GetRead() == InputSize() && !getFileStatus()) return;
        else if (GetRead() == InputSize() && getFileStatus()) {
            DeclineState();
            return;
        }
        if(CheckChar() == '|') {
            IncCharacter();
            S3Block();
        }
        else {
            IncCharacter();
            S2Block();
        }
        return;
    }
    void S2Line() {
        if(GetRead() == InputSize()) return;
        if(CheckChar() != '\n') {
            IncCharacter();
            S2Line();
        }
        else{
            return;
        }
        return;
    }
    void S3Block() {
        if(GetRead() == InputSize() && !getFileStatus()) return;
        else if (GetRead() == InputSize() && getFileStatus()) {
            DeclineState();
            return;
        }
        if(CheckChar() == '#') {
            accepting = true;
            IncCharacter();
            return;
        }
        else {
            IncCharacter();
            S2Block();
        }
        return;
    }
    string str(){
        return ("COMMENT,\"" + TokenCheck::str() + "\"");
    }
};

class IDCheck : public TokenCheck {
public:
    IDCheck(string st = "ID", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    IDCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(isalpha(CheckChar())) {
            IncCharacter();
            S1();
        }
        return;
    }
    void S1() {
        if(GetRead() == InputSize()) return;
        
        
        if(isalpha(CheckChar())|| isdigit(CheckChar())) {
            IncCharacter();
            S1();
        }
        else if(!(isalpha(CheckChar())|| isdigit(CheckChar())))
            return;
        else {
            DeclineState();
        }
    }
    string str(){
        return ("ID,\"" + TokenCheck::str() + "\"");
    }
};

class CommaCheck : public TokenCheck {
public:
    CommaCheck(string st = "COMMA", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    CommaCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == ',') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("COMMA,\"" + TokenCheck::str() + "\"");
    }
};

class PeriodCheck : public TokenCheck {
public:
    PeriodCheck(string st = "PERIOD", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    PeriodCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == '.') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("PERIOD,\"" + TokenCheck::str() + "\"");
    }
};

class Q_MarkCheck : public TokenCheck {
public:
    Q_MarkCheck(string st = "Q_MARK", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    Q_MarkCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == '?') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("Q_MARK,\"" + TokenCheck::str() + "\"");
    }
};


class Left_ParenCheck : public TokenCheck {
public:
    Left_ParenCheck(string st = "LEFT_PAREN", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    Left_ParenCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == '(') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("LEFT_PAREN,\"" + TokenCheck::str() + "\"");
    }
};

class Right_ParenCheck : public TokenCheck {
public:
    Right_ParenCheck(string st = "RIGHT_PAREN", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    Right_ParenCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == ')') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("RIGHT_PAREN,\"" + TokenCheck::str() + "\"");
    }
};

class ColonCheck : public TokenCheck {
public:
    ColonCheck(string st = "COLON", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    ColonCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == ':') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("COLON,\"" + TokenCheck::str() + "\"");
    }
};

class Colon_DashCheck : public TokenCheck {
public:
    Colon_DashCheck(string st = "COLON_DASH", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    Colon_DashCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == ':') {
            IncCharacter();
            S1();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S1() {
        if(GetRead() == InputSize()) {
            DeclineState();
            return;
        }
        
        if(CheckChar() == '-') {
            IncCharacter();
            return;
        }
    }
    string str(){
        return ("COLON_DASH,\"" + TokenCheck::str() + "\"");
    }
};

class MultiplyCheck : public TokenCheck {
public:
    MultiplyCheck(string st = "MULTIPLY", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    MultiplyCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == '*') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("MULTIPLY,\"" + TokenCheck::str() + "\"");
    }
};

class AddCheck : public TokenCheck {
public:
    AddCheck(string st = "ADD", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    AddCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == '+') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("ADD,\"" + TokenCheck::str() + "\"");
    }
};

class SchemesCheck : public TokenCheck {
public:
    SchemesCheck(string st = "SCHEMES", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    SchemesCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == 'S') {
            IncCharacter();
            S1();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S1() {
        if(CheckChar() == 'c') {
            IncCharacter();
            S2();
        }
        else {
            DeclineState();
        }
    }
    void S2() {
        if(CheckChar() == 'h') {
            IncCharacter();
            S3();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S3() {
        if(CheckChar() == 'e') {
            IncCharacter();
            S4();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S4() {
        if(CheckChar() == 'm') {
            IncCharacter();
            S5();
        }
        else {
            DeclineState();
        }
    }
    void S5() {
        if(CheckChar() == 'e') {
            IncCharacter();
            S6();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S6() {
        if(CheckChar() == 's') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
    }
    string str(){
        return ("SCHEMES,\"" + TokenCheck::str() + "\"");
    }
};

class FactsCheck : public TokenCheck {
public:
    FactsCheck(string st = "FACTS", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    FactsCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == 'F') {
            IncCharacter();
            S1();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S1() {
        if(CheckChar() == 'a') {
            IncCharacter();
            S2();
        }
        else {
            DeclineState();
        }
    }
    void S2() {
        if(CheckChar() == 'c') {
            IncCharacter();
            S3();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S3() {
        if(CheckChar() == 't') {
            IncCharacter();
            S4();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S4() {
        if(CheckChar() == 's') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("FACTS,\"" + TokenCheck::str() + "\"");
    }
};

class RulesCheck : public TokenCheck {
public:
    RulesCheck(string st = "RULES", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    RulesCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == 'R') {
            IncCharacter();
            S1();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S1() {
        if(CheckChar() == 'u') {
            IncCharacter();
            S2();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S2() {
        if(CheckChar() == 'l') {
            IncCharacter();
            S3();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S3() {
        if(CheckChar() == 'e') {
            IncCharacter();
            S4();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S4() {
        if(CheckChar() == 's') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("RULES,\"" + TokenCheck::str() + "\"");
    }
};

class QueriesCheck : public TokenCheck {
public:
    QueriesCheck(string st = "QUERIES", string defaultInput = "", size_t defaultCharacterPos = 0) : TokenCheck(st,defaultInput, defaultCharacterPos) {}
    QueriesCheck(const TokenCheck &tc) : TokenCheck(tc) {}
    void S0() {
        if(CheckChar() == 'Q') {
            IncCharacter();
            S1();
        }
        return;
    }
    void S1() {
        if(CheckChar() == 'u') {
            IncCharacter();
            S2();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S2() {
        if(CheckChar() == 'e') {
            IncCharacter();
            S3();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S3() {
        if(CheckChar() == 'r') {
            IncCharacter();
            S4();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S4() {
        if(CheckChar() == 'i') {
            IncCharacter();
            S5();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S5() {
        if(CheckChar() == 'e') {
            IncCharacter();
            S6();
        }
        else {
            DeclineState();
        }
        return;
    }
    void S6() {
        if(CheckChar() == 's') {
            IncCharacter();
            return;
        }
        else {
            DeclineState();
        }
        return;
    }
    string str(){
        return ("QUERIES,\"" + TokenCheck::str() + "\"");
    }
};
#endif /* TokenChecks_h */
