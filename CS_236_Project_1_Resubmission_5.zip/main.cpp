//
//  main.cpp
//  CS_236_Project_1
//
//  Created by AMMON HORTON on 1/26/21.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "Tokenizer.h"
#include "TokenChecks.h"

using namespace std;

int main(int argc, const char * argv[]) {
    
    Tokenizer tker;
    ostringstream outStr;
    
    ifstream inFile(argv[1]);
    tker.readInput(inFile);
    for (TokenCheck* t : tker.tokenVector) {
        outStr << t->str() << endl;
    }
    outStr << "Total Tokens = " << tker.tokenVector.size();
    
    inFile.close();
    
    
    ofstream outFile(argv[2]);
    //Open the output file
    outFile << outStr.str();
    cout << outStr.str();
    //Check status of file
    outFile.close();//*/
    
    return 0;
}
