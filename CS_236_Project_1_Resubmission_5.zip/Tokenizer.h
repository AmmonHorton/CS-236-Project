//
//  Tokenizer.h
//  CS_236_Project_1
//
//  Created by AMMON HORTON on 1/26/21.
//

#ifndef Tokenizer_h
#define Tokenizer_h

#define NUMBER_OF_TOKENS 17

#include "TokenChecks.h"
#include <sstream>
#include <fstream>
#include <vector>

class Tokenizer {
private:
    TokenCheck* fsaArry[NUMBER_OF_TOKENS];
    bool inputNxtLine;
    size_t lengthOfToken;
    size_t correctArryPos;
    size_t correctCharacters;
public:
    vector <TokenCheck*> tokenVector;
    Tokenizer(){
        correctArryPos = 0;
        correctCharacters = 0;
        fsaArry[0] = new UndefinedCheck();
        fsaArry[1] = new StringCheck();
        fsaArry[2] = new CommentCheck();
        fsaArry[3] = new CommaCheck();
        fsaArry[4] = new PeriodCheck();
        fsaArry[5] = new Q_MarkCheck();
        fsaArry[6] = new Left_ParenCheck();
        fsaArry[7] = new Right_ParenCheck();
        fsaArry[8] = new ColonCheck();
        fsaArry[9] = new Colon_DashCheck();
        fsaArry[10] = new MultiplyCheck();
        fsaArry[11] = new AddCheck();
        fsaArry[12] = new SchemesCheck();
        fsaArry[13] = new FactsCheck();
        fsaArry[14] = new RulesCheck();
        fsaArry[15] = new QueriesCheck();
        fsaArry[16] = new IDCheck();
        inputNxtLine = false;
        lengthOfToken = 0;
    }
    ~Tokenizer(void) {
        for(int i = NUMBER_OF_TOKENS; i > 0; i--) {
            delete fsaArry[i - 1];
        }
        for(size_t i = tokenVector.size(); i > 0; i--) {
            delete tokenVector[i - 1];
        }
    }
    TokenCheck* IdentifyToken(string input, size_t line, bool eof = false) {
        correctCharacters = fsaArry[0]->GetRead(input, eof);
        correctArryPos = 0;
        inputNxtLine = false;
        
        
        
        if(input.at(0) == ' ' || input.at(0) == '\t' || input.at(0) == '\n') {
            lengthOfToken = 1;
            return NULL;
        }
        
        for(int i = 0; i < NUMBER_OF_TOKENS; i++) {
            if (fsaArry[i]->GetRead(input, eof) > correctCharacters){
                correctArryPos = i;
                correctCharacters = fsaArry[i]->GetRead(input, eof);
                
            }
        }
        lengthOfToken = correctCharacters;
        if(correctArryPos == 0 && (input.at(0) != '\'' && input.substr(0,2) != "#|")) {
            lengthOfToken = 1;
            fsaArry[correctArryPos]->SetVar(input.substr(0,1), 1, 0);
        }
        else if(correctArryPos == 0) {
            lengthOfToken = input.size();
            fsaArry[correctArryPos]->SetVar(input, input.size(), 0);
        }
        
        
        
        
        
        //The following Lines of code are messy, but they are used to diffreentiate
        //between certain aspects of undefined/Multiline-stirngs/Multiline-comments
        
        if((input.size() == 1 && input.at(0) == '\'') || (correctArryPos == 1 && correctCharacters == input.size() && ((input.at(input.size() - 1)) != '\'' || (input.substr((input.size() - 2), 2) == "''")))) inputNxtLine = true;
        else if(correctArryPos == 2 && correctCharacters == input.size() && input.at(1) == '|' && !(input.substr((input.size() - 2), 2) == "|#")) inputNxtLine = true;
        
        
        if(eof && ((correctArryPos == 1 && !fsaArry[1]->accepting) || (correctArryPos == 2 && !fsaArry[2]->accepting)) && (input.substr(0, 2) == "#|" || input.at(0) == '\'')) {
            lengthOfToken = input.size();
            fsaArry[0]->SetVar(input, lengthOfToken, line);
            return fsaArry[0];
        }
         
        return fsaArry[correctArryPos];
    }
    void readInput(ifstream &inFile) {
        TokenCheck* tcPtr;
        string tempLineStr = ""; //For temporary line assignments
        string tempStr = "";//For temporary word assignments
        ostringstream outStr;
        size_t lineInFile = 1;
        size_t lineIncrease = 0;
        size_t totalTokens = 0;
        
        while(inFile)
        {
            if(!getline(inFile, tempLineStr)) break;
            while(tempLineStr.size() > 0)
            {
                tcPtr = IdentifyToken(tempLineStr, lineInFile, inFile.eof());
                lineIncrease = 0;
                while(inputNxtLine) {
                    tempStr = tempLineStr;
                    getline(inFile, tempLineStr);
                    lineIncrease++;
                    tempLineStr = tempStr + '\n' + tempLineStr;
                    tcPtr = IdentifyToken((tempLineStr), lineInFile, inFile.eof());
                }
                
                if(tcPtr != NULL) {
                    tcPtr->SetVar(lineInFile);
                    AddToVector(tcPtr);
                }
                if(tcPtr != NULL) totalTokens++;
                if(inFile.eof() && tempLineStr.at(tempLineStr.size() - 1) == '\n') lineInFile--;
                tempLineStr.erase(0, lengthOfToken);
                lineInFile += lineIncrease;
            }
            lineInFile++;
            tempStr = "";
        }
        tokenVector.push_back(new EOFCheck("EOF", lineInFile));
        totalTokens++;
        //For EOF Token
    }
    void AddToVector(TokenCheck* tcPtr) {
        if(correctArryPos == 0) tokenVector.push_back(new UndefinedCheck(*tcPtr));
        else if(correctArryPos == 1) tokenVector.push_back(new StringCheck(*tcPtr));
        else if(correctArryPos == 2) tokenVector.push_back(new CommentCheck(*tcPtr));
        else if(correctArryPos == 3) tokenVector.push_back(new CommaCheck(*tcPtr));
        else if(correctArryPos == 4) tokenVector.push_back(new PeriodCheck(*tcPtr));
        else if(correctArryPos == 5) tokenVector.push_back(new Q_MarkCheck(*tcPtr));
        else if(correctArryPos == 6) tokenVector.push_back(new Left_ParenCheck(*tcPtr));
        else if(correctArryPos == 7) tokenVector.push_back(new Right_ParenCheck(*tcPtr));
        else if(correctArryPos == 8) tokenVector.push_back(new ColonCheck(*tcPtr));
        else if(correctArryPos == 9) tokenVector.push_back(new Colon_DashCheck(*tcPtr));
        else if(correctArryPos == 10) tokenVector.push_back(new MultiplyCheck(*tcPtr));
        else if(correctArryPos == 11) tokenVector.push_back(new AddCheck(*tcPtr));
        else if(correctArryPos == 12) tokenVector.push_back(new SchemesCheck(*tcPtr));
        else if(correctArryPos == 13) tokenVector.push_back(new FactsCheck(*tcPtr));
        else if(correctArryPos == 14) tokenVector.push_back(new RulesCheck(*tcPtr));
        else if(correctArryPos == 15) tokenVector.push_back(new QueriesCheck(*tcPtr));
        else if(correctArryPos == 16) tokenVector.push_back(new IDCheck(*tcPtr));
        return;
    }
    
    
    size_t GetLengthOfToken() {return lengthOfToken;}
};

#endif /* Tokenizer_h */
